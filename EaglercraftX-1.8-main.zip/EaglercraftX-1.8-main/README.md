# **EaglercraftX-1.8.9**
This is the HTML for EaglercraftX (Minecraft 1.8.9), as of 12/02/22
<br>**THIS IS NOT MINE, IT WAS CODED BY AYUNAMI2000.**<br>
Also, don't bug me about bugs or anything, because I don't know tons of coding languages and I've only taken 3 classes.
<br>I will keep updating this until an official EaglercraftX repo is created.<br>
<ul>most servers are currently unavailable, as they're being updated to 1.8<ul>
<ul>Singleplayer is also unavailable<ul>

**Links**
<br>https://eggler.vercel.app



